
$(document).ready(function(){
	$('.share').mouseenter(function(){
		$(".drop_box2").css('display','block'); 
	});
	$('.drop_box').mouseleave(function(){
		// $('.drop_box2').hidden();
		$(".drop_box2").css('display','none'); 
	});
	$('.heart').mouseenter(function(){
		$(".drop_box2").css('display','none'); 
	});
	var num=0;
	$('.heart').on('click',function(){
		num++;
		$('.heart img').attr('src','images/heart_03.png');
		if(num==2){
			alert('你已经收藏过了');
		}; 
	});
	$('.img_right').click(function(){
		$('.roll_list>div').animate({left:'-852px'});
		$('.img_left').show();
		$(this).hide();
	});
	$('.img_left').click(function(){
		$('.roll_list>div').animate({left:''})
		$(this).hide();
		$('.img_right').show()
	});
		var oldval1=parseInt($('.PX-1>span').text()) ;
		$('.PX-1>img').click(function(){
		$(this).attr('src','images/praise_1_13.png')
		$('.PX-1>span').text(oldval1+1);
	});
		var oldval2=parseInt($('.PX-2>span').text()) ;
		$('.PX-2>img').click(function(){
		$(this).attr('src','images/praise_1_13.png')
		$('.PX-2>span').text(oldval2+1);
	});
		var oldval3=parseInt($('.PX-3>span').text()) ;
		$('.PX-3>img').click(function(){
		$(this).attr('src','images/praise_1_13.png')
		$('.PX-3>span').text(oldval3+1);
	});
		var oldval4=parseInt($('.PX-4>span').text()) ;
		$('.PX-4>img').click(function(){
		$(this).attr('src','images/praise_1_13.png')
		$('.PX-4>span').text(oldval4+1);
	});


	$('.g_span1').mouseenter(function(){
		$(this).css('borderBottom','1px solid #ff9900').siblings().css('borderBottom','0px');
	})
	$('.g_span2').mouseenter(function(){
		$(this).css('borderBottom','1px solid #ff9900').siblings().css('borderBottom','0px');
	});
	$('.angellist1').on('click',function(){
		$('.angelPicture>img').attr('src','images/tstz_benner_01.png');
	});
	$('.angellist2').on('click',function(){
		$('.angelPicture>img').attr('src','images/tstz_benner_02.png');
	});
	$('.angellist3').on('click',function(){
		$('.angelPicture>img').attr('src','images/tstz_benner_03.png');
	});
	$('.angellist4').on('click',function(){
		$('.angelPicture>img').attr('src','images/tstz_benner_04.png');
	});
	$('.angellist5').on('click',function(){
		$('.angelPicture>img').attr('src','images/tstz_benner_05.png');
	});
	$('.angelaside>span').on('click',function(){
		$('.angelaside ul').scrollTop(750);
	});
	$('.angel_s1').on('click',function(){
		$('.angel_s1>img').attr('src','images/activity_collect-hover.png');
	});
	$('.angel_s2').on('click',function(){
		$('.angel_s2>img').attr('src','images/activity_share-hover.png');
	});
	$('.angel_s3').on('click',function(){
		$('.angel_s3>img').attr('src','images/activity_collect-hover.png');
	});
	$('.angel_s4').on('click',function(){
		$('.angel_s4>img').attr('src','images/activity_share-hover.png');
	});
	$('.angel_s5').on('click',function(){
		$('.angel_s5>img').attr('src','images/activity_collect-hover.png');
	});
	$('.angel_s6').on('click',function(){
		$('.angel_s6>img').attr('src','images/activity_share-hover.png');
	});
	$('.angel_s7').on('click',function(){
		$('.angel_s7>img').attr('src','images/activity_collect-hover.png');
	});
	$('.angel_s8').on('click',function(){
		$('.angel_s8>img').attr('src','images/activity_share-hover.png');
	});
	$('.menu-sort-list>li').mouseenter(function(){
		$(this).find('div').show();
	}).mouseleave(function(){
		 $(this).find("div").hide().stop();
	});
	$('.menu-sort-Tlist>li').mouseenter(function(){
		$(this).find('div').show();
	}).mouseleave(function(){
		 $(this).find("div").hide().stop();
	});
	
	   // $('.menu-sort-list>li')
    //     .on('mouseenter',function(){
    //         $('.menu-item-content').removeClass('none')
    //     })
    //     .on('mouseleave',function(){
    //         $('.menu-item-content').addClass('none')

    //         if(activeRow){
    //             activeRow.removeClass('active')
    //             activeRow = null;
    //         }

    //         if(activeMenu){
    //             activeMenu.addClass('none')
    //             activeMenu = null;
    //         }
    //     });	
       
    $('.institution-list>li')
    .on('mouseenter',function(){
    	$(this).addClass('institutionsjq')
    })
    .on('mouseleave',function(){
    	$(this).removeClass('institutionsjq')
    });
});